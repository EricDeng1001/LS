module.exports = socketServer => {
  socketServer.on("connection" , socket => {
    
  });
}
