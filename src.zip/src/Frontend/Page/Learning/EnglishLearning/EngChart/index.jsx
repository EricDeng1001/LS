import React from 'react';
import style from 'style';

class EngChart extends React.PureComponent {
  constructor( props ){
    super( props );
  }

  render(){
    return(
      <React.Fragment>
        <div> chart</div>

      </React.Fragment>
    )
  }




}


export default EngChart
