import React from 'react';
import style from 'style';

class Benkexuexi extends React.PureComponent {
  constructor( props ){
    super( props );
  }

  render(){
    return(
      <React.Fragment>
        <div><div> 本课学习 </div></div>

      </React.Fragment>
    )
  }




}


export default Benkexuexi
