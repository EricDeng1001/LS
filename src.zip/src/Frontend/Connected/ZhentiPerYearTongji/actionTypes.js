export const __ASYNC_LOAD_ZHENTI_TONGJI = {
  pending: "ZhentiTongji/__LOAD_ZHENTI_TONGJI_PENDING",
  resolved: "ZhentiTongji/__LOAD_ZHENTI_TONGJI_RESOLVED",
  rejected: "ZhentiTongji/__LOAD_ZHENTI_TONGJI_REJECTED"
};
