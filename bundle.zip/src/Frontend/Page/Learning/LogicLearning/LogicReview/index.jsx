import React from 'react';
import style from 'style';

//import KnowLedge from 'Page/LogicSubject/KnowLedge';
//import ZhongDian from 'Page/LogicSubject/ZhongDian';
//import QiangHua from 'Page/LogicSubject/QiangHua';
//import UnitTest from 'Page/LogicSubject/UnitTest';

class LogicReview extends React.PureComponent {
  constructor( props ){
    super( props );
  }

  render(){
    return(
      <React.Fragment>
        <div><div> 普通复习 </div></div>

        <div> 重点复习 </div>
      </React.Fragment>
    )
  }




}


export default LogicReview
