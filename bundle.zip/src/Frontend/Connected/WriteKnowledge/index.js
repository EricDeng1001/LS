import view from 'layout';
import * as actions from 'actions';
import reducer from 'reducer';
export { view , actions , reducer };
