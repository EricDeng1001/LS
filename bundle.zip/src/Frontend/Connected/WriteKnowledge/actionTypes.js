export const __ASYNC_LOAD_WRITE_KNOWLEDGE = {
  pending: "WriteKnowledge/__LOAD_WRITE_CONTENTS_PENDING",
  resolved: "WriteKnowledge/__LOAD_WRITE_CONTENTS_RESOLVED",
  rejected: "WriteKnowledge/__LOAD_WRITE_CONTENTS_REJECTED"
};
