export const __SET_BUTTON_CHOICE = "BUTTON_EXPAND/__SET_BUTTON_CHOICE";

export const __ASYNC_LOAD_BUTTON_CONTENTS = {
  pending: "ButtonExpand/__LOAD_BUTTON_CONTENTS_PENDING",
  resolved: "ButtonExpand/__LOAD_BUTTON_CONTENTS_RESOLVED",
  rejected: "ButtonExpand/__LOAD_BUTTON_CONTENTS_REJECTED",
};
