import logger from "redux-logger";
import thunk from "redux-thunk";
export default {
  middleWare: [ logger , thunk ]
} ;
