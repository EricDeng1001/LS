module.exports = {
  username: "",
  password: "",
  host: "localhost",
  port: "",
  database: "mongo"
};
