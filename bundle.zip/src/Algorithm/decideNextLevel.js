export default ( calced , resList ) => {
  return 0;
}
